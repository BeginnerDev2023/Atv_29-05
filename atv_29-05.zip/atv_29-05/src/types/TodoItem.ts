type TodoItem = {
  id: number
  title: string
  description: string
}

export default TodoItem