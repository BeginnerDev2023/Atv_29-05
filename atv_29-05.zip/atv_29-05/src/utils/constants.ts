export const storageTodoListKey = '@todo-list-key'
export const loginTokenKey = '@login-token-key'
